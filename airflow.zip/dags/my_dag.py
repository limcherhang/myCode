from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from datetime import datetime
from airflow.providers.mysql.hooks.mysql import MySqlHook
import logging

logging.basicConfig(level=logging.INFO)

def execute_query():
    mysql_hook = MySqlHook(mysql_conn_id='wsl_conn')
    records = mysql_hook.get_records(sql="SELECT * FROM airflow.ab_permission;")
    for record in records:
        logging.info(record)

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2024, 1, 1),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1
}

with DAG('my_test_dag', default_args=default_args, schedule_interval='@once') as dag:
    task = PythonOperator(
        task_id='execute_query_task',
        python_callable=execute_query
    )