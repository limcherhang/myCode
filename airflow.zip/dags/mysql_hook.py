from airflow.providers.mysql.hooks.mysql import MySqlHook

# 建立 MySQLHook
mysql_hook = MySqlHook(mysql_conn_id='wsl_conn')

# 定義查詢 SQL
sql_query = "SELECT * FROM airflow.ab_permission;"

# 執行查詢指令
results = mysql_hook.get_records(sql_query)

# 輸出結果
for row in results:
   print(row)